
export class LogDto {
  adminId: number;
  action: string;
}