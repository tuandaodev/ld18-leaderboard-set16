import { Router } from "express";
import { exportLeaderBoardCSV, getLeaderBoardList, initUsersLeaderBoard, testController, uploadCSV } from "./leader-board.controller";

export const leaderBoardRouter = Router();

leaderBoardRouter.get("/list", getLeaderBoardList);
// initUsersLeaderBoard and exportLeaderBoardCSV are now arrays of middleware
leaderBoardRouter.get("/init-user", initUsersLeaderBoard as any);
leaderBoardRouter.post("/export-leaderboard", exportLeaderBoardCSV as any);

// leaderBoardRouter.get("/test", testController);

leaderBoardRouter.post('/upload-data', uploadCSV as any);